<?php 
$kata = array("ada", "abel", "men", "pung", "nilai");
echo "Array ". $kata[0]. "lah suatu vari".$kata[1]. " yang dapat ". $kata[2]."am".$kata[3]. " banyak ". $kata[4];


 ?>