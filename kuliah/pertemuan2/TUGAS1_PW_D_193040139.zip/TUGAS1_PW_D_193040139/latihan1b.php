<?php 
$angka = 15;
echo "Aku adalah angka ".$angka;
echo "<br>";

$angka *=5;
echo "jika aku dikali 5 maka, aku sekarang bernilai ". $angka;
echo "<br>";

$angka /=3;
echo "jika aku dibagi 3 maka, aku sekarang bernilai ".$angka;
echo "<br>";

$angka -=30;
echo "jika aku dkurang1 30 maka, aku sekarang bernilai ".$angka;
echo "<br>";

$angka +=10;
echo "jika aku ditambah 10 maka, aku sekarang bernilai ". $angka;


 ?>