<?php 
$a = 1;
while ($a <= 3) {
	for ($b=1; $b <= 3 ; $b++) { 
	echo "ini pengulangan ke ($a,$b)";
	echo "<br>";	
	}
	$a++;
}


 ?>